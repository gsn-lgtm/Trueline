# TrueLine (personal)

Private iPhone field map. Home base: Jefferson County, Alabama.
Not an App Store product. Not monetized. Queries official public county GIS only.

## On your iPhone
1. Host the `web/` folder (GitHub Pages, Netlify, or any static host) over HTTPS — Safari needs HTTPS for GPS.
2. Open `index.html` in Safari.
3. Share → Add to Home Screen.
4. Allow Location.

Default map: Birmingham / Jefferson County. The Jefferson layer is the county’s own parcel service, rebuilt nightly.

Dropdown covers other Alabama counties with public query URLs (Tuscaloosa, Madison, Mobile, Baldwin, Clay). Counties without a query URL open the official viewer. Census geocoding tries to switch county when you tap across a line.

## Native SwiftUI
`ios/TrueLine/Sources` — open in Xcode on a Mac, sideload to your phone. Same Jefferson endpoint.

## What this is not
Not LandGlide data. Not ReportAll. Not a survey. Not for resale.
