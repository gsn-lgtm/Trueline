import SwiftUI
import MapKit

struct MapWorkspace: View {
    @EnvironmentObject var location: LocationModel
    @EnvironmentObject var parcels: ParcelStore
    @State private var camera: MapCameraPosition = .region(
        MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 33.5207, longitude: -86.8025),
            span: MKCoordinateSpan(latitudeDelta: 0.04, longitudeDelta: 0.04)
        )
    )
    @State private var query = ""
    @State private var satellite = true

    var body: some View {
        ZStack(alignment: .bottom) {
            MapReader { proxy in
                Map(position: $camera, interactionModes: .all) {
                    if let c = location.coordinate {
                        Annotation("You", coordinate: c) {
                            ZStack {
                                Circle().stroke(.cyan.opacity(0.5), lineWidth: 2)
                                    .frame(width: 28, height: 28)
                                Circle().fill(.cyan).frame(width: 10, height: 10)
                            }
                        }
                        MapCircle(center: c, radius: max(location.accuracy, 5))
                            .foregroundStyle(.cyan.opacity(0.12))
                            .stroke(.cyan.opacity(0.4), lineWidth: 1)
                    }
                    ForEach(parcels.overlays) { p in
                        MapPolygon(p.overlay)
                            .foregroundStyle(.green.opacity(0.15))
                            .stroke(.green, lineWidth: 2)
                    }
                    if location.track.count > 1 {
                        MapPolyline(coordinates: location.track)
                            .stroke(.blue, lineWidth: 3)
                    }
                }
                .mapStyle(satellite ? .imagery(elevation: .realistic) : .standard)
                .onTapGesture { pos in
                    if let coord = proxy.convert(pos, from: .local) {
                        Task { await parcels.identify(at: coord) }
                    }
                }
                .ignoresSafeArea()
            }

            VStack(spacing: 10) {
                HStack {
                    Text("TRUE").font(.caption.weight(.bold)) + Text("LINE").font(.caption.weight(.bold)).foregroundStyle(.green)
                    TextField("Owner, PIN, address", text: $query)
                        .textFieldStyle(.roundedBorder)
                        .onSubmit { Task { await parcels.search(query) } }
                }
                .padding(10)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14))
                .padding(.horizontal)
                .padding(.top, 8)

                Spacer()

                HStack {
                    Text(gpsLine).font(.caption2.monospaced())
                    Spacer()
                    Button("◎") { recenter() }
                    Button(location.recording ? "■" : "⌖") {
                        location.recording.toggle()
                        if !location.recording { location.track.removeAll() }
                    }
                    Button("▣") { satellite.toggle() }
                }
                .padding(.horizontal)

                ParcelCard()
            }
        }
        .onAppear { location.request() }
    }

    var gpsLine: String {
        if location.denied { return "Location denied" }
        guard location.accuracy >= 0 else { return "GPS waiting" }
        let acc = Int(location.accuracy.rounded())
        let hdg = location.heading >= 0 ? " · \(Int(location.heading))°" : ""
        return "GPS ±\(acc) m\(hdg)"
    }

    func recenter() {
        guard let c = location.coordinate else { return }
        camera = .region(MKCoordinateRegion(center: c, span: MKCoordinateSpan(latitudeDelta: 0.004, longitudeDelta: 0.004)))
        Task { await parcels.identify(at: c) }
    }
}

struct ParcelCard: View {
    @EnvironmentObject var parcels: ParcelStore
    @EnvironmentObject var location: LocationModel

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("TAX MAP · NOT A SURVEY")
                .font(.caption2.weight(.bold))
                .foregroundStyle(.yellow)
            if let p = parcels.selected {
                Text(p.owner).font(.headline)
                row("PIN", p.pin)
                if let acres = p.acres { row("Calc. acres", String(format: "%.2f", acres)) }
                row("Source", "\(p.sourceName) · \(p.sourceVintage)")
                if let url = p.officialURL {
                    Link("Open official county GIS", destination: url)
                }
                Text("GPS accuracy now: \(location.accuracy >= 0 ? "\(Int(location.accuracy)) m" : "unknown"). Do not build a fence from this screen.")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            } else {
                Text(parcels.status).font(.subheadline).foregroundStyle(.secondary)
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .padding(.horizontal)
        .padding(.bottom, 8)
    }

    func row(_ k: String, _ v: String) -> some View {
        HStack {
            Text(k).foregroundStyle(.secondary)
            Spacer()
            Text(v).multilineTextAlignment(.trailing)
        }
        .font(.subheadline)
    }
}
