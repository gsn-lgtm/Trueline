import Foundation
import CoreLocation
import MapKit

struct ParcelRecord: Identifiable, Hashable {
    let id: String
    var owner: String
    var pin: String
    var acres: Double?
    var mailing: String
    var sourceName: String
    var sourceVintage: String
    var officialURL: URL?
    var coordinate: CLLocationCoordinate2D
    var overlay: MKPolygon

    func hash(into hasher: inout Hasher) { hasher.combine(id) }
    static func == (lhs: ParcelRecord, rhs: ParcelRecord) -> Bool { lhs.id == rhs.id }
}

extension CLLocationCoordinate2D: @retroactive Hashable {
    public func hash(into hasher: inout Hasher) {
        hasher.combine(latitude); hasher.combine(longitude)
    }
    public static func == (lhs: CLLocationCoordinate2D, rhs: CLLocationCoordinate2D) -> Bool {
        lhs.latitude == rhs.latitude && lhs.longitude == rhs.longitude
    }
}
