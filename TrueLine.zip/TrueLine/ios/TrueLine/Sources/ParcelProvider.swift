import Foundation
import CoreLocation
import MapKit

/// Swap this for Regrid / ReportAll / Parceled when you have a license key.
protocol ParcelProviding {
    func parcel(at coordinate: CLLocationCoordinate2D) async throws -> ParcelRecord?
    func search(_ query: String) async throws -> [ParcelRecord]
}

struct JeffersonCountyPublicProvider: ParcelProviding {
    /// Official Jefferson County AL parcel MapServer, updated nightly. Personal use of public GIS.
    let endpoint = URL(string: "https://jccgis.jccal.org/server/rest/services/Basemap/Parcels/MapServer/0")!

    func parcel(at coordinate: CLLocationCoordinate2D) async throws -> ParcelRecord? {
        var comps = URLComponents(url: endpoint.appendingPathComponent("query"), resolvingAgainstBaseURL: false)!
        let geom = "{\"x\":\(coordinate.longitude),\"y\":\(coordinate.latitude),\"spatialReference\":{\"wkid\":4326}}"
        comps.queryItems = [
            .init(name: "f", value: "json"),
            .init(name: "geometry", value: geom),
            .init(name: "geometryType", value: "esriGeometryPoint"),
            .init(name: "inSR", value: "4326"),
            .init(name: "spatialRel", value: "esriSpatialRelIntersects"),
            .init(name: "outFields", value: "*"),
            .init(name: "returnGeometry", value: "true"),
            .init(name: "outSR", value: "4326")
        ]
        let (data, _) = try await URLSession.shared.data(from: comps.url!)
        return parse(data).first
    }

    func search(_ query: String) async throws -> [ParcelRecord] {
        let metaURL = URL(string: endpoint.absoluteString + "?f=json")!
        let (metaData, _) = try await URLSession.shared.data(from: metaURL)
        let meta = try JSONSerialization.jsonObject(with: metaData) as? [String: Any]
        let fields = (meta?["fields"] as? [[String: Any]] ?? []).compactMap { $0["name"] as? String }
        let owner = fields.first { $0.localizedCaseInsensitiveContains("owner") }
        let pin = fields.first { $0.localizedCaseInsensitiveContains("pin") || $0.localizedCaseInsensitiveContains("parcel") }
        let escaped = query.replacingOccurrences(of: "'", with: "''")
        var clauses: [String] = []
        if let owner { clauses.append("UPPER(\(owner)) LIKE UPPER('%\(escaped)%')") }
        if let pin { clauses.append("UPPER(\(pin)) LIKE UPPER('%\(escaped)%')") }
        guard !clauses.isEmpty else { return [] }
        var comps = URLComponents(url: endpoint.appendingPathComponent("query"), resolvingAgainstBaseURL: false)!
        comps.queryItems = [
            .init(name: "f", value: "json"),
            .init(name: "where", value: clauses.joined(separator: " OR ")),
            .init(name: "outFields", value: "*"),
            .init(name: "returnGeometry", value: "true"),
            .init(name: "outSR", value: "4326"),
            .init(name: "resultRecordCount", value: "20")
        ]
        let (data, _) = try await URLSession.shared.data(from: comps.url!)
        return parse(data)
    }

    private func parse(_ data: Data) -> [ParcelRecord] {
        guard
            let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
            let features = obj["features"] as? [[String: Any]]
        else { return [] }

        return features.compactMap { feat in
            let attrs = feat["attributes"] as? [String: Any] ?? [:]
            let geom = feat["geometry"] as? [String: Any]
            let rings = geom?["rings"] as? [[[Double]]]
            guard let firstRing = rings?.first, firstRing.count >= 3 else { return nil }
            var coords = firstRing.map { CLLocationCoordinate2D(latitude: $0[1], longitude: $0[0]) }
            let poly = MKPolygon(coordinates: &coords, count: coords.count)
            let owner = string(attrs, keys: ["Owner", "OWNER", "OWNER_NAME", "ownname"])
            let pin = string(attrs, keys: ["PIN", "ParcelNum", "PARCELID", "parcel_id", "PARCEL_ID"])
            let acres = number(attrs, keys: ["GIS_Acres", "GISACRES", "Acres", "ACRES", "CalcAcres"])
            let centroid = coords[coords.count / 2]
            return ParcelRecord(
                id: pin.isEmpty ? UUID().uuidString : pin,
                owner: owner.isEmpty ? "Unknown owner" : owner,
                pin: pin,
                acres: acres,
                mailing: string(attrs, keys: ["MailAdd1", "MAIL_ADD1", "situs_display"]),
                sourceName: "Jefferson County AL official GIS",
                sourceVintage: "Nightly county update",
                officialURL: URL(string: "https://jccgis.jccal.org/"),
                coordinate: centroid,
                overlay: poly
            )
        }
    }

    private func string(_ attrs: [String: Any], keys: [String]) -> String {
        for k in keys {
            if let v = attrs[k] { return String(describing: v) }
            if let match = attrs.keys.first(where: { $0.caseInsensitiveCompare(k) == .orderedSame }),
               let v = attrs[match] { return String(describing: v) }
        }
        return ""
    }

    private func number(_ attrs: [String: Any], keys: [String]) -> Double? {
        for k in keys {
            if let v = attrs[k] as? Double { return v }
            if let v = attrs[k] as? Int { return Double(v) }
            if let match = attrs.keys.first(where: { $0.caseInsensitiveCompare(k) == .orderedSame }),
               let v = attrs[match] as? Double { return v }
        }
        return nil
    }
}

@MainActor
final class ParcelStore: ObservableObject {
    @Published var selected: ParcelRecord?
    @Published var overlays: [ParcelRecord] = []
    @Published var status = "Tap the map or search"
    let provider: ParcelProviding = JeffersonCountyPublicProvider()

    func identify(at coordinate: CLLocationCoordinate2D) async {
        status = "Querying county layer…"
        do {
            if let parcel = try await provider.parcel(at: coordinate) {
                selected = parcel
                overlays = [parcel]
                status = "Tax map · \(parcel.sourceVintage)"
            } else {
                selected = nil
                status = "No parcel in the active public layer"
            }
        } catch {
            status = error.localizedDescription
        }
    }

    func search(_ q: String) async {
        status = "Searching…"
        do {
            let hits = try await provider.search(q)
            overlays = hits
            selected = hits.first
            status = hits.isEmpty ? "No matches" : "\(hits.count) match(es)"
        } catch {
            status = error.localizedDescription
        }
    }
}
