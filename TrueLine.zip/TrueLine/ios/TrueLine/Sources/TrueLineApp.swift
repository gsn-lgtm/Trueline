import SwiftUI

@main
struct TrueLineApp: App {
    @StateObject private var location = LocationModel()
    @StateObject private var parcels = ParcelStore()

    var body: some Scene {
        WindowGroup {
            MapWorkspace()
                .environmentObject(location)
                .environmentObject(parcels)
                .preferredColorScheme(.dark)
        }
    }
}
