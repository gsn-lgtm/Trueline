# TrueLine — product brief

TrueLine is a field-first property-line app designed to do what LandGlide does, then fix the things that get people in trouble.

## What LandGlide does well
- GPS + parcel overlay on a phone
- Search by owner / address / PIN
- National coverage via licensed ReportAll data
- Offline-ish field use
- Pins, notes, export

## Deficiencies TrueLine is built to improve

| LandGlide problem | TrueLine response |
|---|---|
| Lines look more official than they are | Persistent **Not a survey** banner. Legal vs tax-map distinction. |
| Ownership months/years stale | **Freshness badge** on every parcel (source date + county link). |
| GPS drift in woods | Accuracy halo, heading, smoothed track, “walked path vs mapped line”. |
| No uncertainty | Optional **confidence buffer** around tax-map lines. |
| Dead-end data | Deep link to **county assessor / alabamagis / recorded docs**. |
| Forced 7-day trial, $100/yr | Local-first; paid commercial layer is optional and labeled. |
| One vendor, one vintage | **Provider stack**: official county GIS first, licensed national second. |
| Hard to take into Garmin / QGIS | GPX + KML + GeoJSON export. |
| Thin rural situs addresses (Clay AL ~0–33%) | Owner + PIN + mailing + PLSS, not just street address. |

## What this repo can and cannot do

**Can**
- Ship an iPhone Home Screen web app you can use in the field today.
- Ship a SwiftUI project you open in Xcode and run on your phone.
- Query public county ArcGIS layers (Clay County AL sample included).
- Overlay FEMA flood zones, measure, drop pins, record a walk.

**Cannot (without your accounts and money)**
- Redistribute ReportAll / Regrid / CoreLogic nationwide parcels. Those require a commercial license.
- Publish to the App Store. That requires your Apple Developer Program membership ($99/yr) and App Store review.
- Replace a licensed Alabama land surveyor. Tax maps are not deeds.

## Recommended data stack (when you go production)

1. **County official GIS** — always shown as source of truth for that county.
2. **Licensed national API** — Regrid, ReportAll (same company as LandGlide), Parceled.ai, or GetParcelData — behind a paid toggle.
3. **Public overlays** — FEMA NFHL, SSURGO soils, PAD-US public land, NWI wetlands.
4. **User layer** — pins, photos, walked tracks stored on device.

Clay County, AL official viewer: https://www.alabamagis.com/Clay/
Revenue Commissioner maps note: https://www.claycountyrevenue.com/
Regrid last refresh for Clay AL (example): 2026-08-05 (~17.6k parcels).
Sample public FeatureServer used in the prototype:
`https://services1.arcgis.com/Ug5xGQbHsD8zuZzM/ArcGIS/rest/services/Clay_County_Parcels_10_23/FeatureServer/0`
(labeled Oct 2023 — the app surfaces that date on purpose).
